﻿using System;

namespace Puzal
{
    using System.Collections.Generic;
    using System.Threading.Tasks.Sources;

    class Program
    {
        static void Main(string[] args)
        {
            var souce = new List<string>()
                            {
                                "M1",
                                "M2",
                                "M3",
                                "C1",
                                "C2",
                                "C3"
                            };
            var destination=new List<string>();

            var traveller=new List<string>();

            traveller = souce;
            var otherside = destination;
            while (destination.Count != 6)
            {
                

                Console.WriteLine("Values at other side");
                    foreach (var x in otherside)
                    {
                        Console.WriteLine(x);
                    }
                Console.WriteLine("Values at our side");
                foreach (var x in traveller)
                {
                    Console.WriteLine(x);
                }


                Console.WriteLine("Enter first string of M/C into boat");
                    var firstelement = Console.ReadLine();
                    Console.WriteLine("Enter second element to boat or Enter No to move boat");
                    var secondelement = Console.ReadLine();
                    if (traveller.Equals(souce))
                    {
                        destination.Add(firstelement);

                        traveller.Remove(firstelement);
                        if (secondelement != "No")
                        {
                            destination.Add(secondelement);
                            traveller.Remove(secondelement);
                        }
                    }
                    else if (traveller.Equals(destination))
                    {
                        souce.Add(firstelement);

                        traveller.Remove(firstelement);
                        if (secondelement != "No")
                        {
                            souce.Add(secondelement);
                            traveller.Remove(secondelement);
                        }
                    }



                    if (traveller.Equals(souce))
                    {
                        souce = traveller;
                        traveller = destination;
                        otherside = souce;
                    }
                    else if (traveller.Equals(destination))
                    {
                        destination = traveller;
                        traveller = souce;
                        otherside = destination;
                    }
            }

            Console.WriteLine("Other end of River");
            foreach (var x in destination)
            {
                Console.WriteLine(x);
            }

            Console.ReadKey();




        }
    }
}
