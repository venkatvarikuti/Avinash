﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    public class SailBoat
    {
        private State _inputState;
        public static State GetState(State inputState)
        {
            if (inputState.isGoal())
            {
                return inputState;
            }

            Queue<State> q=new Queue<State>();
            q.Enqueue(inputState);
            
            HashSet<State> treeSet = new HashSet<State>();
          
            while (true)
            {
                if (q.Count==0)
                {
                    return null;
                }

                State state = q.Dequeue();
                treeSet.Add(state);
                List<State> pathList = state.ValidStateFinder();

                foreach (var path in pathList)
                {
                    if (!pathList.Contains(path) || !q.Contains(path))
                    {
                        if (path.isGoal())
                        {
                            return path;
                        }
                        q.Enqueue(path);
                    }
                }
            }

        }
    }

}
