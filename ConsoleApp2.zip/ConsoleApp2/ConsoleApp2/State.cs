﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    public enum River
    {
        Left,
        Right
    }
    public class State
    {
        private int cannibalLeft;
        private int missionaryLeft;
        private int cannibalRight;
        private int missionaryRight;
        private River boat;
        public string count;
        private State parentState;


        public State(int cannibalLeft, int missionaryLeft, River boat, int cannibalRight, int missionaryRight, string count)
        {

            this.cannibalLeft = cannibalLeft;
            this.missionaryLeft = missionaryLeft;
            this.boat = boat;
            this.cannibalRight = cannibalRight;
            this.missionaryRight = missionaryRight;
            this.count = count;
        }


        public List<State> ValidStateFinder()
        {
            List<State> pathList = new List<State>();
            if (boat == River.Left)
            {

                isvalidStateLeft(pathList, new State(cannibalLeft, missionaryLeft - 2, River.Right, cannibalRight, missionaryRight + 2, " 0C,2M "));
                isvalidStateLeft(pathList, new State(cannibalLeft - 2, missionaryLeft, River.Right, cannibalRight + 2, missionaryRight, " 2C,0M "));
                isvalidStateLeft(pathList, new State(cannibalLeft - 1, missionaryLeft - 1, River.Right, cannibalRight + 1, missionaryRight + 1, " 1C,1M "));
                isvalidStateLeft(pathList, new State(cannibalLeft, missionaryLeft - 1, River.Right, cannibalRight, missionaryRight + 1, " 0C,1M "));
                isvalidStateLeft(pathList, new State(cannibalLeft - 1, missionaryLeft, River.Right, cannibalRight + 1, missionaryRight, " 1C,0M "));
            }
            else
            {
                isvalidStateRight(pathList, new State(cannibalLeft, missionaryLeft + 2, River.Left, cannibalRight, missionaryRight - 2, " 0C,2M "));
                isvalidStateRight(pathList, new State(cannibalLeft + 2, missionaryLeft, River.Left, cannibalRight - 2, missionaryRight, " 2C,0M "));
                isvalidStateRight(pathList, new State(cannibalLeft + 1, missionaryLeft + 1, River.Left, cannibalRight - 1, missionaryRight - 1, " 1C,1M "));
                isvalidStateRight(pathList, new State(cannibalLeft, missionaryLeft + 1, River.Left, cannibalRight, missionaryRight - 1, " 0C,1M "));
                isvalidStateRight(pathList, new State(cannibalLeft + 1, missionaryLeft, River.Left, cannibalRight - 1, missionaryRight, " 1C,0M "));

            }
            return pathList;

        }
        static int i = 0;
        public void isvalidStateLeft(List<State> pathList, State newPath)
        {
            if (newPath.checkValidpath())
            {
                newPath.setParentState(this); // setting  newpath as a parent ref
                pathList.Add(newPath); //storing new path in the linkedlist
            }

        }


        public void isvalidStateRight(List<State> pathList, State newPath)
        {
            if (newPath.checkValidpath())
            {
                newPath.setParentState(this); // setting  newpath as a parent ref
                pathList.Add(newPath); //storing new path in the linkedlist

            }

        }

        public bool checkValidpath()
        {
            if (missionaryRight >= 0 && missionaryLeft >= 0 && cannibalLeft >= 0 &&
            cannibalRight >= 0 && (missionaryRight == 0 || missionaryRight >= cannibalRight) && (missionaryLeft == 0 || missionaryLeft >= cannibalLeft))
            {
                return true;
            }
            return false;

        }


        public  String ToStringFirst()
        {
            if (boat == River.Left)
            {
                return "[ " + cannibalLeft + "C," + missionaryLeft + "M ] <--";
            }
            else
            {
                return "[ " + cannibalLeft + "C," + missionaryLeft + "M ] --> ";
            }
        }

        public String ToStringSecond()
        {
            if (boat == River.Left)
            {
                return " <--  [" + cannibalRight + "C " + missionaryRight + "M ]";
            }
            else
            {
                return " -->  [" + cannibalRight + "C " + missionaryRight + "M ]";
            }
        }

        //goal is achieved when the state reaches to 0cannibals and 0missioinaries on left side the river
        public bool isGoal()
        {
            return cannibalLeft == 0 && missionaryLeft == 0;
        }

        public int getCannibalLeft()
        {
            return cannibalLeft;

        }

        public void setCannibalLeft(int cannibalLeft)
        {
            this.cannibalLeft = cannibalLeft;
        }

        public int getMissionaryLefft()
        {
            return missionaryLeft;
        }
        public void setMissionaryLeft(int missionaryLeft)
        {
            this.missionaryLeft = missionaryLeft;
        }
        public int getCannibalRight()
        {
            return cannibalRight;
        }

        public int getMissionaryRight()
        {
            return missionaryRight;
        }

        public void setMissionaryRight(int missionaryRight)
        {
            this.missionaryRight = missionaryRight;
        }

        public State getParentState()
        {
            return parentState;

        }

        //when we get a valid state we set as a parent refrence 
        public void setParentState(State parentState)
        {
            this.parentState = parentState;
        }
    }
}
