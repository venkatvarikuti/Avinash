﻿using System;

namespace ConsoleApp2
{
    using System.Collections.Generic;
    using System.Linq;

    class Program
    {
        static void Main(string[] args)
        {
            State inputState = new State(3, 3, River.Left, 0, 0, " 0C,0M ");
            var result = SailBoat.GetState(inputState);

            printPath(result);


        }

        static void printPath(State result)
        {

            if (null == result)
            {
                Console.WriteLine("not found");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("path ");
                List<State> pathList = new List<State>();
                State path = result;
                while (null != path)
                {
                    pathList.Add(path);
                    path = path.getParentState();

                }


                int depth = pathList.Count - 1;
                for (int i = depth; i >= 0; i--)
                {

                    path = pathList.ElementAt(i);
                    if (path.isGoal())
                    {
                        Console.WriteLine(path.ToStringFirst() + " " + path.count + " " + path.ToStringSecond());
                    }
                    else
                    {
                        Console.WriteLine(path.ToStringFirst() + " " + path.count + " " + path.ToStringSecond());
                    }
                }

                Console.WriteLine("depth : " + depth);

                Console.ReadKey();
            }
        }
    }
}
